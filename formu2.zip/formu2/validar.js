function validar(){
    var pnombre, papellido, fecha, nnumeroi, cedula, edad, expresion;
    nombre = document.getElementById("pnombre").Value;
    papellido = document.getElementById("papellido").Value;
    fecha = document.getElementById("fecha").Value;
    nnumeroi = document.getElementById("nnumeroi").Value;
    cedula = document.getElementById("cedula").Value;
    edad = document.getElementById("edad").Value;
    
    if(pnombre === ""){
        alert("El campo nombre esta vacio");

    }
}